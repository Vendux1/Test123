number = int(input("Give me a number: "))
if (number % 2) == 0:
    print("Even")
else:
    print("Odd")