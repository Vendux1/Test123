width = float(input("Give the width: "))
length = float(input("Give the length: "))
print("Total area of room: ", width * length)