days = int(input("Amount of days: "))
print("Hours:", days * 24,','  "Minutes: " , days * 24 *60,',' "Seconds: "  , days * 24 * 60 * 60 )
