widget = int(input("Amount of widgets: "))
gizmo = int(input("Amount of gizmo: "))
weight = widget * 75 + gizmo * 112
print("Total weight is: ", weight)