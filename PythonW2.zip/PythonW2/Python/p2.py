years = int(input("Give amount of years: "))
print("Months:",years * 12,',' "Days:",years * 365)