name = input("Whats your name: ")
print("Hello ", name)