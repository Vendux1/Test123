years = input("Give me an random amount of years: ")
if (int(years) % 4) == 0:
    print("Leap year")
else:
    print("Not a leap year")